package com.transferstatement;
//continue use is skip current iteration on the continue for the next iteration
//we can use "continue" only and only in loops
public class Continue_InsideLoop {
public static void main(String[]args){
	for(int i=0;i<10;i++){
		if(i%2==0)
			continue;
		System.out.println(i);
	}
}
}
