package com.selectionstatement;

public class IfElse8 {
	public static void main(String[]args){
		if(true){
		int x=10;
		System.out.println("hiii");
		}
		

		
	}
}
