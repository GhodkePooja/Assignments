package com.selectionstatement;

public class Switch2 {
	public static void main(String[]args){
		
	//curly braces are mandetory in switch case and optional in everywhere
int x=1;
switch(x){
case 0:
	System.out.println("pooja");
case 1:
	System.out.println("anarthe");
}
}
}
