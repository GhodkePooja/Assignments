package com.selectionstatement;

public class DefaultSwitch {
	public static void main(String[] args) {
		// in switch case we have to declare any statement in case or default
		// only.
		// single independent statement not allowed otherwise it will get
		// compile time error.
		int x = 10;
		switch (x) {
		case 0:
			System.out.println("0");
		case 1:
			System.out.println("1");
		case 2:
			System.out.println("2");
		default:
			System.out.println("defalut case generate");
		}
	}
}
