package com.selectionstatement;

public class Switch4 {
	public static void main(String[]args){
byte x=1;
switch(x){

case 0:
	System.out.println("ABC");
case 1:
	System.out.println("XYZ");
	
}
}}
