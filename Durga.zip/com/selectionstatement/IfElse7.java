package com.selectionstatement;

public class IfElse7 {
	public static void main(String[]args){
		
		if(true);
		System.out.println("hii");
		
	}

}
