package com.selectionstatement;

public class IfElse3 {
	public static void main(String[]args){
		int x=10;
		if(x>20){
			System.out.println("Hello");
		
		}
		else{
			System.out.println("hii");
		}
	}
}
