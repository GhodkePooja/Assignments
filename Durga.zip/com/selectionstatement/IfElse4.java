package com.selectionstatement;

public class IfElse4 {
	public static void main(String[] args) {
		boolean b = false;
		if (b = false) {
			System.out.println("hello");

		} else {
			System.out.println("hii");
		}
	}
}
