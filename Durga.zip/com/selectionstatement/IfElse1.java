package com.selectionstatement;

public class IfElse1 {
	public static void main(String[] args) {
		int x = 1;
		if (x < 10) {
			System.out.println("Hello");

		} else {
			System.out.println("hii");
		}
	}
}
