package com.selectionstatement;

public class Switch1 {
public static void main(String[]args){
	
	int a=0;
	switch(a){
	case 0:
		System.out.println("january");
		
	case 1:
		System.out.println("february");
		
	case 2:
		System.out.println("march");
		
	case 3:
		System.out.println("april");
		
	case 4:
		System.out.println("may");
	case 5:
		System.out.println("june");
	case 6:
		System.out.println("july");
	case 7:
		System.out.println("august");
	case 8:
		System.out.println("september");
	case 9:
		System.out.println("october");
	case 10:
		System.out.println("november");
	case 11:
		System.out.println("december");
	}
}
}
