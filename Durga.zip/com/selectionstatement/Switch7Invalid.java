package com.selectionstatement;
// it is invalid
public class Switch7Invalid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=10;
switch(x+1){
case 10:
	System.out.println("x+1");
}
	}

}
