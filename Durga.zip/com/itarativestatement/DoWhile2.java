package com.itarativestatement;

public class DoWhile2 {
public static void main(String[]args){
	do{
		System.out.println("pooja ghodke");
		}
		while(10>20);
	
}
}
