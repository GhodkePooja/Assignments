package com.itarativestatement;

public class While1 {
public static void main(String[]args){
	int b=0;
	while (b<100)
		System.out.println("hello");
}
}
