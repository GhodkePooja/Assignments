package com.itarativestatement;
//for each loop designed for 1.5 version
//it is specially designed for collections and arrays 
//use of for each loop is to print element of one dimensinal aray
public class For_Each_Enhancedloop1 {
public static void main(String[]args){
	int[]x={10,20,30,40,50};
	for(int i=x.length-1;i>0;i--)
	{
		System.out.println(x[i]);
	}
}
}
