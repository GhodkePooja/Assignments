package com.itarativestatement;

public class For4 {
public static void main(String[]args){
	for(;;)
		System.out.println("hello");
}
}
