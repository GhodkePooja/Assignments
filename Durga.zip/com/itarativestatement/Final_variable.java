package com.itarativestatement;

public class Final_variable {
public static void main(String[]args){
	final int a=10;
	int b=20;
	System.out.println(a);
	System.out.println(b);
}

}
