package com.itarativestatement;

public class Final_Variable1 {
public static void main(String[]args){
	final int a=10,b=20;
	int c=30;
	System.out.println(a+b);
	System.out.println(a+c);
	System.out.println(a<b);
	System.out.println(a<c);
	
}
}
