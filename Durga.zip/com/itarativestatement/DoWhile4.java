package com.itarativestatement;

public class DoWhile4 {
public static void main(String[]args){
	int a=10;
	int b=20;
	do{
		System.out.println("hello");
	}while(a>b);
		System.out.println("hii");
}
}
