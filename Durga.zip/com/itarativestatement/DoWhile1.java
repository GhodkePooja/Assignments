package com.itarativestatement;

public class DoWhile1 {
public static void main(String[]args){
	do{
		System.out.println("hello");
		}
		while(false);//semocolom is mandatory
		
	}
}

