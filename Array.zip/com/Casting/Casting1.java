package com.Casting;

public class Casting1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]=new int[5];
a[0]=1;
byte b=10;
a[1]=b;
short s=20;
a[2]=s;
char c1='a';
a[3]=c1;
char c2='b';
a[4]=c2;
for(int var:a){
	System.out.println(var);
	
}
	}

}
