package com.Casting;

public class HashCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a1[]=new int[3];
a1[0]=10;
a1[1]=20;
a1[2]=30;
System.out.println(a1[0]);
System.out.println("value of hashcode a1[0]:"+a1.hashCode());
int a2[]=new int[3];
a2[0]=40;
a2[1]=50;
a2[2]=60;
System.out.println("value of hashcode a2[0]:"+a2.hashCode());
a1=a2;
System.out.println(a1[0]);
System.out.println(a2[0]);
System.out.println("value of hashcode for a1:"+a1.hashCode());
System.out.println("value of hashcode for a2:"+a2.hashCode());
	}

}
