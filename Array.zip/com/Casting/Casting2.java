package com.Casting;

public class Casting2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int c[]=new int[3];
int c1='x';
c[0]=c1;
int c2='y';
c[1]=c2;
int c3='z';
c[2]=c3;
for(int var:c){
	System.out.println(var);
}
	}

}
