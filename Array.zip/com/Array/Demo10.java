package com.Array;

public class Demo10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=10;
int[]a=new int[i];
int j=10;
int []b=new int[j];
byte k=10;
byte[]c=new byte[k];
System.out.println(a.length);
System.out.println(b.length);
System.out.println(c.length);

	}

}
