package com.Array;

public class Demo5 {

	public static void main(String[] args) {
	
	int a2[]=new int[5];
	a2[0]=5;
	a2[1]=10;
	a2[2]=15;
	a2[3]=10;
	System.out.println(a2[1]);
	System.out.println(a2[2]);
	System.out.println(a2[3]);
	
	

	}

}
