package com.Array;

public class ArrayLiterals {
//if you know array element then we used array literals.
	public static void main(String[] args) {
		int [] a=new int [] {10,20,30,40,50};
		 System.out.println(a.length);

	}

}
