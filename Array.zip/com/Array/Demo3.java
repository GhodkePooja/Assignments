package com.Array;

public class Demo3 {
public static void main(String[]args){
	
	float a2[]=new float[5];
	a2[0]=1;
	a2[1]=2;
	a2[2]=3;
	a2[3]=4;
	a2[4]=5;
	System.out.println(a2[0]);
	System.out.println(a2[1]);
	System.out.println(a2[2]);
	System.out.println(a2[3]);
	System.out.println(a2[4]);
}
}
