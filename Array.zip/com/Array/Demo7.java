package com.Array;

public class Demo7 {

	public static void main(String[] args) {
	

double a2[]=new double [5];
a2[0]=5;
a2[1]=10;
a2[2]=15;
a2[3]=20;
a2[4]=25;
System.out.println(a2[0]);
System.out.println(a2[1]);
System.out.println(a2[2]);
System.out.println(a2[3]);
System.out.println(a2[4]);
System.out.println(a2[5]);

	}

}
