package com.Array;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

float f2[]=new float[5];
f2[0]=1;
f2[1]=2;
f2[2]=3;
f2[3]=4;
f2[4]=5;

System.out.println(f2[0]);
System.out.println(f2[1]);
System.out.println(f2[2]);
System.out.println(f2[3]);
System.out.println(f2[4]);
	}

}
