package com.Array;

public class Demo8 {

	public static void main(String[] args) {
		int a2[]=new int[-5];
		System.out.println(a2[1]);

	}

}
