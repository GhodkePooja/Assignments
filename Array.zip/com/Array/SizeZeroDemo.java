package com.Array;

public class SizeZeroDemo {
public static void main(String[]args){
	int a1[]=new int [0];
	System.out.println(a1.length);
	
}
}
