package com.Array;

public class LoopsInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a1[]=new int[5];
a1[0]=1;
a1[1]=2;
a1[2]=3;
a1[3]=4;
a1[4]=5;
System.out.println("Size of array:"+a1.length);
int size=a1.length;
for(int b=0;b<=size-1;b++){
	System.out.println(a1[b]);
}
	}

}
