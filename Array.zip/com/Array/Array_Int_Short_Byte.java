package com.Array;

public class Array_Int_Short_Byte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size=10;

int a1[]=new int[size];
byte b=10;
int a2[]=new int[b];
short s=10;
int a3[]=new int[s];
char c='a';
int a4[]=new int[c];
System.out.println(a1[0]);
System.out.println(a2[0]);
System.out.println(a3[0]);
System.out.println(a4.length);



	}

}
