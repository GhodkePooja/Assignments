package com.Array;

public class Demo11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=10;
int []a1=new int [i];
System.out.println(a1.length);
	}

}
