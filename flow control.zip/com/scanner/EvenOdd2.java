package com.scanner;
import java.util.Scanner;
public class EvenOdd2 {
public static void main(String[]args){
	System.out.println("Enter a number");
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	if(a%2==0){
		System.out.println("given number is even");
	}else
	{
		System.out.println("given number is odd");
	}
}
}
