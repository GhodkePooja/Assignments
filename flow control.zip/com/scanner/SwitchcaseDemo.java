package com.scanner;

import java.util.Scanner;

public class SwitchcaseDemo {
	public static void main(String[] args) {
		
		System.out.println("press 0 for addition");
		System.out.println("press 1 for substraction");
		System.out.println("press 2 for multiplication");
		System.out.println("press 3 for division");
		Scanner sc = new Scanner(System.in);
		int case_select = sc.nextInt();
		System.out.println("Enter 1st number");
		int num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		int num2 = sc.nextInt();
		switch (case_select) {
		case 0: {
			System.out.println("addition of num1 and num2:" + (num1 + num2));
		}break;
		case 1: {
			System.out
					.println("substraction of num1 and num2:" + (num1 - num2));
		}break;
		case 2: {
			System.out.println("multiplication of num1 and num2:"
					+ (num1 * num2));
		}break;
		case 3: {
			System.out.println("division of num1 and num2:" + (num1 / num2));
		}break;
		}
	}
}
