package com.vision;

public class Ifelseif3 {
public static void main(String[]args){
	int a=10;
	if(a>5){
		System.out.println("value of a is greater than 5");
	}else if(a<15){
		System.out.println("value of a is less than 15");}
		else if(a==10){
			System.out.println("value of a is equal to 10");
		
	}}
		
}
