package com.vision;

public class Nestingifelse {
	public static void main(String[] args) {

		int n1 = 12;
		int n2 = 30;
		if (n1 < n2) {
			System.out.println("n1 is less than n2");
			if (n1 <= n2)
				
			System.out.println("n1 is less than or equal to n2");

			if (n1 > n2)
				
			System.out.println("n1 is greater than n2");

		} else {

			System.out.println("value is wrong");
		}
	}

}
