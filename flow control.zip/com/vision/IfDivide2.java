package com.vision;

public class IfDivide2 {
public static void main(String[]args){
	int a=10;
	int b=2;
	if(a/b==5){
		System.out.println("Division is correct");
	}else{
		System.out.println("Division is wrong");
	}
}
}
