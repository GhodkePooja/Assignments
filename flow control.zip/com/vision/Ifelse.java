package com.vision;

public class Ifelse {
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 20;
		if (num1 > num2) {

			System.out.println("value of num 1 is greater than num2");
		} else {
			System.out.println("value is wrong");
		}
	}
}
