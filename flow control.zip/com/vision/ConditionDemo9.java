package com.vision;

public class ConditionDemo9 {
	public static void main(String[] args) {
		int a = 10;
		int b = 15;
		int c = (a & b);
		if (c == 10) {
			System.out.println("value of c is 10");

		} else {
			System.out.println("value of c is wrong");
		}
	}
}
