package com.vision;

public class EvenOddDemo2 {
public static void main(String[]args){
	
	int num=15;
	if(num%2==0){
		System.out.println("given number is even");
	}else
		System.out.println("given number is odd");
}
}
