package com.vision;

public class Ifmultiply2 {
public static void main(String[]args){
	int a=2;
	int b=3;
	if(a*b==6){
		System.out.println("Multiplication is correct");
	}else
	{
		System.out.println("Multiplication is wrong");
	}
}
}
