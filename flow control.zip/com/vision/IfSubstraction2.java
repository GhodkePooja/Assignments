package com.vision;

public class IfSubstraction2 {
public static void main(String[]args){
	int a=10;
	int b=9;
	if(a-b==10){
		System.out.println("substration is correct");
	}else{
		System.out.println("substraction is wrong");
	}
}
}
