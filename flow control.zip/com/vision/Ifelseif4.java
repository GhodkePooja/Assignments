package com.vision;

public class Ifelseif4 {
	public static void main(String[] args) {
		int a = 95;
		if (a < 100) {

			System.out.println("value of a is less than 100");
		} else if (a > 50) {
			System.out.println("value of a is greater than 50");
		}
	}
}
