package com.vision;

public class ConditionDemo1 {
	public static void main(String[] args) {
		int a = 100;
		if (a == 100) {

			System.out.println("a is  equal to 100");
			if (a < 200) {
				System.out.println("a is less than 200");
			}
			if (a > 50) {
				System.out.println("a is greater than 50");

			}

		}

		else {
			System.out.println("output is wrong");
		}
	}
}
