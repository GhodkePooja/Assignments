package com.vision;

public class Nestingifelse2 {
	public static void main(String[] args) {
		int num = 40;
		if (num == 40) {
			System.out.println("value of num is equal to 40");
			if (num > 30)
				System.out.println("value of num is greater than 30");
			if (num < 50)
				System.out.println("value of num is less than 50");
		} else {
			System.out.println("value of num is wrong");
		}
	}
}