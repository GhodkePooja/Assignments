package com.vision;

public class Ifelseif1 {
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 12;
		if (num1 < num2) {

			System.out.println("if block executes");

		} else if (num1 > num2) {
			System.out.println("else block executes");
		}
	}
}
