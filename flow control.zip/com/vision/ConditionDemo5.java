package com.vision;

public class ConditionDemo5 {
	public static void main(String[] args) {
		double d1 = 13.4335;
		double d2 = 45.34683;

		if (d1 < d2) {
			System.out.println("d1 is less than d2");

		} else {
			System.out.println("value is wrong");
		}

	}
}
