package com.vision;

public class Ifelse2 {
	public static void main(String[]args){
float f1=11.234f;
float f2=23.3456f;
if(f1>f2){
	System.out.println("value is true");
}
else{
	System.out.println("value is false");
}
}
}