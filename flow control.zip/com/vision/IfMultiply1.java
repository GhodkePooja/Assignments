package com.vision;

public class IfMultiply1 {
	public static void main(String[] args) {

		int a = 10;
		int b = 15;
		if (a * b == 1150) {
			System.out.println("multiplication is correct");

		} else {
			System.out.println("multiplication is wrong");
		}
	}
}
