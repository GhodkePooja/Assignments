package com.vision;

public class EvenOddDemo {
	public static void main(String[] args) {
		int num = 10;
		if (num % 2 == 0) {
			System.out.println("number is even");
		} else {
			System.out.println("number is odd");
		}
	}
}
