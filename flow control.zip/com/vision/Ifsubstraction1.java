package com.vision;

public class Ifsubstraction1 {
public static void main(String[]args){
	int a=10;
	int b=5;
	if(a-b==5){
		System.out.println("value of substraction is correct");
	}else{
		System.out.println("value of substraction is wrong");
	}
}
}
