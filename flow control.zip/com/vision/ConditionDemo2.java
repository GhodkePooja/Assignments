package com.vision;

public class ConditionDemo2 {
	public static void main(String[] args) {
		String s = ("pooja");
		String d = ("satish");

		if (s + d != null) {
			System.out.println("pooja satish");

		} else {
			System.out.println("pooja anarthe");
		}

	}
}
