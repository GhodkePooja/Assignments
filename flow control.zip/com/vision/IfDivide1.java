package com.vision;

public class IfDivide1 {
public static void main(String[]args){
	int a=3;
	int b=9;
	if(b/a==1){
		System.out.println("Division is correct");
	}else
	{
		System.out.println("Division is wrong");
	}
}
}
