package com.vision;

public class ConditionDemo3 {
public static void main(String[]args){
	
	String s="pooja";
	String e="anarthe";
	if (s+e!=null){
		
		System.out.println("pooja anarthe");
		
	}
	else{
		System.out.println("name is wrong");
	}
	
	
}
}
