package com.vision;

public class Ifelse3 {
	public static void main(String[] args) {
		double d = 10;
		double b = 12;
		if (b > d) {
			System.out.println("value of double is true");
		} else {
			System.out.println("value of double is false");
		}
	}
}
