package com.Loops;

public class WhileLoop3 {
public static void main(String[]args){
	boolean b=false;
	while(b){
		System.out.println("Hello i am pooja");
	}
}
}
