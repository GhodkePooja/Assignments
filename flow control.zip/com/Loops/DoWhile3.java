package com.Loops;

public class DoWhile3 {
public static void main(String[]args){
	boolean b=false;
	do{
		System.out.println("hello diyara");
	}while(b);
}
}
