package com.Loops;

public class WhileDemo {
public static void main(String[]args){
	int num1=1;
	int num2=20;
	while(num1<num2){
		System.out.println(++num1);
	}
}
}
