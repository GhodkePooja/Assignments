package com.Loops;

public class WhileDemo6 {
public static void main(String[]args){
	
	int a=10;
	while(a<20){
		System.out.println("hello");
	}
}
}
