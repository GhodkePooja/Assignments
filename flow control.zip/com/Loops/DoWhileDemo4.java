package com.Loops;

public class DoWhileDemo4 {
public static void main(String[]args){
	boolean b=false;
	do{
		System.out.println("i am diyara satish anarthe");
	}while(b);
}
}
