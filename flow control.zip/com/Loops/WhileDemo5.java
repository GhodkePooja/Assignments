package com.Loops;

public class WhileDemo5 {
public static void main(String[]args){
	int a=11;
	int b=22;
	while(a>b){
		System.out.println("hello");
	
	
}}}
