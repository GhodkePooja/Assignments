package com.Loops;

public class DoWhileDemo3 {
public static void main(String[]args){
	boolean b=true;
	do{
		System.out.println("i am pooja");
	}while(b);
}
}
