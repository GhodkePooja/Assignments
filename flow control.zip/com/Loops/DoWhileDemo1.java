package com.Loops;

public class DoWhileDemo1 {
public static void main(String[]args){
	int a=1;
	int b=2;
	do{
		System.out.println("hello Diyara");
	}while(a<b);
}
}
