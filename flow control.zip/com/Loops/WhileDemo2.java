package com.Loops;

public class WhileDemo2 {
public static void main(String[]args){
	boolean b=true;
	while(b){
	System.out.println("hii");
}}
}
