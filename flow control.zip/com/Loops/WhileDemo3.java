package com.Loops;

public class WhileDemo3 {
public static void main(String[]args){
	boolean b=false;
	while(b){
		System.out.println("hii");
	}
}
}
