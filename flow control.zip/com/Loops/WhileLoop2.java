package com.Loops;

public class WhileLoop2 {
public static void main(String[]args){
	boolean b=true;
	while(b){
		System.out.println("i am diyara");
	}
}
}
