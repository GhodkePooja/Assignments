package com.Loops;

public class WhileLoop1 {

	public static void main(String[] args) {
		boolean b = true;
		while (b){
		System.out.println("Hii Pooja");
		System.out.println("How are you");
	}
}
}