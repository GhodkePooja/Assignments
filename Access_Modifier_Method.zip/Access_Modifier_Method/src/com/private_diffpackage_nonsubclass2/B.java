package com.private_diffpackage_nonsubclass2;
import com.private_diffpackage_nonsubclass1.A;
public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//A a1=new A();not allowed
//a1.m1();
//B b1=new B();
//b1.m1();
	}

}
