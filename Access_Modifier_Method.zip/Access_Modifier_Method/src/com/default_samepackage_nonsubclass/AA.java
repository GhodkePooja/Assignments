package com.default_samepackage_nonsubclass;

class AA {
void m1(){
	System.out.println("class AA method called");
}
}
