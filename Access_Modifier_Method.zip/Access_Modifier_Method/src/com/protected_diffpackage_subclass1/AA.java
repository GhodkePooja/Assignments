package com.protected_diffpackage_subclass1;

public class AA {
protected void m1(){
	System.out.println("class AA method called"+ " using child object only");
}
}
