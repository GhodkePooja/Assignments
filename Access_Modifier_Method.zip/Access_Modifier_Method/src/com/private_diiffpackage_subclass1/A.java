package com.private_diiffpackage_subclass1;

public class A {
private void m1(){
	System.out.println("class A method called");
}
}
