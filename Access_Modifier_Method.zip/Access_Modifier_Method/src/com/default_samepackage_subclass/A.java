package com.default_samepackage_subclass;
 class A {
void m1(){
	System.out.println("class A method called");
}
}
