package com.final_samepackage_nonsubclass;

public class A {
final void m1(){
	System.out.println("class A method called");
}
}
