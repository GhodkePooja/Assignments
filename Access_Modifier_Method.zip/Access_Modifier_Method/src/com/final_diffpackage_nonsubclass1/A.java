package com.final_diffpackage_nonsubclass1;

public class A {
final void m1(){
	System.out.println("class A method called");
}
}
