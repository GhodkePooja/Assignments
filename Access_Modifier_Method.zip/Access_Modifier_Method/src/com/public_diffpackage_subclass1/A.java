package com.public_diffpackage_subclass1;

public class A {
	public void m1(){
		System.out.println("class A method called");
	}
}
