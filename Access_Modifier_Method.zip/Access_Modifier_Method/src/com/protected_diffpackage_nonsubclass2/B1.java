package com.protected_diffpackage_nonsubclass2;
import com.protected_diffpackage_nonsubclass1.A1;
public class B1 {
public static void main(String[]args){
	A1 a=new A1();
	//a.m1();//not allowed
	B1 b=new B1();
	//b.m1();not allowed here we are not using extends keywords
}
}
