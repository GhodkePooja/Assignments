package com.private_samepackage_subclass;

public class B extends A{
public static void main(String[]args){
	A a1=new A();
	B b1=new B();
	A a2=new B();
//	a1.m1();
	//a2.m1();
	//b1.m1();//here we are not accessing subclass of same package also
}
}
