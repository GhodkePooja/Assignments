package com.visionedutech;

public class demo {
public static void main(String[]args){

 int a=10;
 int b=20;
 
 if(a<b){
	 System.out.println("a is less than b");
	 
 }
}
	 
	 
 }



