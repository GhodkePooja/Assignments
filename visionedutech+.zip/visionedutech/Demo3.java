package com.visionedutech;

public class Demo3 {
public static void mai(String[]args){
	
	int a=11;
	int b=22;
	if(a<b){
		System.out.println("a is less than b");		
		
	}
	else{
		System.out.println("a is greater than b");
	}
	
}
}
