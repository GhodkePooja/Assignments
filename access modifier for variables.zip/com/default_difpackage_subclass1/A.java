package com.default_difpackage_subclass1;

public class A {
short s=50;
}
