package com.public_diffpackage_subclass2;
import com.public_diffpackage_subclass1.A;
public class B extends A{
public static void main(String[]args){
	A a1=new A();
	System.out.println(a1.f);
}
}
