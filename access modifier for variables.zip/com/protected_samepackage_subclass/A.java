package com.protected_samepackage_subclass;

public class A {
protected short s=100;
}
