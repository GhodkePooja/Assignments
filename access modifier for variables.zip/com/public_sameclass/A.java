package com.public_sameclass;

public class A {
public int i=10;
public static void main(String[]args){
	A a1=new A();
	System.out.println(a1.i);
}
}
