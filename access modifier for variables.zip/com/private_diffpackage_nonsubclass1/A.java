package com.private_diffpackage_nonsubclass1;

public class A {
private byte b=10;
}
