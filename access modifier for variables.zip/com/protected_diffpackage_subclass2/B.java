package com.protected_diffpackage_subclass2;
import com.protected_diffpackage_subclass1.A;
public class B extends A{
public static void main(String[]args){
	A a1=new A();
	B b1=new B();
	System.out.println(b1.i);
//System.out.println(a1.i); reference of parent class not allowed
}
}
