package com.protected_diffpackage_nonsubclass1;

public class A {
protected int i=10;
}
