package com.private_diffpackage_nonsubclass2;
import com.private_diffpackage_nonsubclass1.A;
public class B {
public static void main(String[]args){
	A a1=new A();
	//System.out.println(a1.l);not allowed
}
}
