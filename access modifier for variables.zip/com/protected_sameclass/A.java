package com.protected_sameclass;

public class A {
protected int i=15;
public static void main(String[]args){
	A a1=new A();
	System.out.println(a1.i);
}
}
