package com.public_samepackage_subclass;

public class B extends A{
public static void main(String[]args){
	A a1=new A();
	System.out.println(a1.s);
}
}
