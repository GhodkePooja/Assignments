package com.private_samepackage_subclass;

public class A {
private double d=101l;

}
