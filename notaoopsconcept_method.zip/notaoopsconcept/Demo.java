package com.notaoopsconcept;
//getter method
public class Demo {
int i;
public int m1(){
	return i;
}
public static void main(String[]args){
	Demo d=new Demo();
	System.out.println(d.m1());
	
}
}
