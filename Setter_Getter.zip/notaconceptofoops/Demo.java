package com.notaconceptofoops;

public class Demo {
int i;
//user defined method
public void m1(int i){
	this.i=i;
}
//created by java,setter method
public void setI(int i) {
	this.i = i;
}
public String toString() {
	return "Demo [i=" + i + "]";
}
public static void main(String[]args){
	Demo d=new Demo();
	
	//d.i=10;
	//d.m1(10);
	//output of setter value
	d.setI(20);
	System.out.println(d);
	Demo d1=new Demo();
		d1.m1(20);	
		System.out.println(d1);
		
}


}
