package com.edutech;

public class Switch2 {
	public static void main(String[] args) {

		int a = 2;
		switch (a) {
		case 0: {
			System.out.println("case 0 is executed");
		}
		case 1: {
			System.out.println("case 1 is executed");
		}
		case 2: {
			System.out.println("case 2 is executed");
		}
		}
	}
}