package com.edutech;

public class String {
public static void main(java.lang.String[]args){
	System.out.println("welcome pooja");
}
}
