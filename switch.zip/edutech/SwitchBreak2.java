package com.edutech;

public class SwitchBreak2 {
	public static void main(String[] args) {
		int a = 1;
		switch (a) {
		case 0: {
			System.out.println("case 0 is executed");
		}
			break;
		case 1: {
			System.out.println("case 1 is executed");
		}
			break;
		case 2: {
			System.out.println("case 2 is executed");

		}
			break;
		default: {
			System.out.println("defalut case is executed");
		}
		}
	}
}