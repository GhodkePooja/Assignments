package com.edutech;

public class SwitchShort1 {
	public static void main(String[] args) {

		short s = 124;
		switch (s) {
		case 0: {
			System.out.println("case 0 is executed");
		}
		case 1: {
			System.out.println("case 1 is executed");

		}
		case 2: {
			System.out.println("case 2 is exeuted");
		}
		default:
			System.out.println("default case is executed");
		}
	}
}
