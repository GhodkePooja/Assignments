package com.scopeofvariable;

public class LocalDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//here main method is also one method
		int i=10;
		i++;
		System.out.println(i);
	}
	

}
