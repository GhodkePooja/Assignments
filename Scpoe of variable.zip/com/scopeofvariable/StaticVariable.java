package com.scopeofvariable;

public class StaticVariable {
static int i;
public static void main(String[]arga){
	System.out.println("calling static variable directly in main method:"+i);
	StaticVariable s=new StaticVariable();
	System.out.println("calling static variable by using object reference:"+s.i);
	System.out.println("calling static variable using class name:"+StaticVariable.i);
}
}
