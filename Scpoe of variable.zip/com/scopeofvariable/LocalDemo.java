package com.scopeofvariable;

public class LocalDemo {
	
	int m;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
LocalDemo s=new LocalDemo();
System.out.println(s.m);

	}

}
