package com.scopeofvariable;

public class InstanceVariable {
int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
InstanceVariable i1= new InstanceVariable();
System.out.println(i1.i);
	}

}
