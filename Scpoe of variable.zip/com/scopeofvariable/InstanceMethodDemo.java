package com.scopeofvariable;

public class InstanceMethodDemo {
int i;
public void m1(){
	System.out.println("method called");
	System.out.println("Instance Method");
}
public static void main(String[]args){
	InstanceMethodDemo I=new InstanceMethodDemo();
I.m1();
	InstanceMethodDemo I1=new InstanceMethodDemo();

I1.m1();
}}
