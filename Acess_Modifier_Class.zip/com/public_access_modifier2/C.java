package com.public_access_modifier2;
import com.public_access_modifier1.A;
public class C extends A {
public static void main(String[]args){
	//we can access class from different packages also in public access modifier
}
}
