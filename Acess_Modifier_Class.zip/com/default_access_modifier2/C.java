package com.default_access_modifier2;
//import com.default_access_modifier1.A;
//public class C extends A{

//}
//if access modifier is default we can access a class from same packages
//but we cant access classes from different packages