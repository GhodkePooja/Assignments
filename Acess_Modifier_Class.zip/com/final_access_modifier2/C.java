package com.final_access_modifier2;
//import com.final_access_modifier1.A;
//public class C extends A {

//}
//we can not access class from same packages as well different package also in 
//final access modifier
