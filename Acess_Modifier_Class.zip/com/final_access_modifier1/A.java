package com.final_access_modifier1;

final class A {
	public static void main(String[]args){
		A a1=new A();
}}
