package com.final_access_modifier1;

//final class B extends A{

//}
