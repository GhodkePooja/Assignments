package com.public_access_modifier1;

public class A {
public static void main(String[]args){
	A a1=new A();
}
}
