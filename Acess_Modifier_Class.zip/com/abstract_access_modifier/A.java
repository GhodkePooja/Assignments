package com.abstract_access_modifier;
// we can't create object for abstact class
abstract class A {
public static void main(String[]args){
//	A a1=new A();
}
}
