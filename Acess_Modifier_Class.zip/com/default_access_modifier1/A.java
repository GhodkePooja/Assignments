package com.default_access_modifier1;

 class A {
public static void main(String[]args){
	A a1=new A();
}
}
