package com.default_access_modifier1;

public class B extends A {

}
