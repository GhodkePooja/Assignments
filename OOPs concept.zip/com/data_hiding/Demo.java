package com.data_hiding;
//if we ant to hide data or method we can use " private" as a access modifier
//by using private access modifier we cannot directly see that data or method
public class Demo {
private int i;
private void m1(){
	System.out.println("class A method");
}//but if we generate getter and setter method the we can indirectly see that hided method 
//or data
}
