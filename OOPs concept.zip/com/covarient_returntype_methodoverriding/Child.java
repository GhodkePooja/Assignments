package com.covarient_returntype_methodoverriding;

public class Child extends Parent{
public String m1(){
	return "Child class method";
}
public Integer m2(){
	return 20;
}
//public Object abcd(){
	//return "a";
//}
//public int abc(){
	//return 10;
//}
public static void main(String[]args){
	Parent p1=new Parent();
	Object p2=new Child();
	Object p3=new String();
	Parent p4=new Child();
	System.out.println(p4.m1());
	System.out.println(p4.m2());
}
}
