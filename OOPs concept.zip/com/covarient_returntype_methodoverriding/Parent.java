package com.covarient_returntype_methodoverriding;

public class Parent {
public Object m1(){
	return "parent class method called";
}
public String abcd(){
	return "a";
}
public long abc(){
	return 10l;
	
}
public Object m2(){
	return 10;
}
}
