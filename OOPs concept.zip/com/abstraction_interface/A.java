package com.abstraction_interface;

public interface A {
int m=20;
final int k=40;
public static final int l=20;
public static final double pi=3.1414;
//constant value
public abstract void m1();
}
