package com.abstraction_interface;

public interface C extends A{

}
