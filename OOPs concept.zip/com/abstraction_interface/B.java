package com.abstraction_interface;

public class B implements A{

	public void m1() {
		System.out.println("A interface abstract implemented into child clas B");	
	}
	public double areaof_circle(int radius){
		return (A.pi * radius);
	}
	public static void main(String[]args){
		B b1=new B();
//		System.out.println(b1.m=30);
		System.out.println(b1.areaof_circle(20));
		
		
	}

}
