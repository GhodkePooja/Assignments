package com.hybridinheritance;

//public class ClassE extends ClassA extends ClassB {
//public void m5(){
//	System.out.println("class E method called");
//}
//}
