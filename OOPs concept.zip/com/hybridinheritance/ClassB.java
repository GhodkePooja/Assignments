package com.hybridinheritance;

public class ClassB extends ClassA {
public void m2(){
	System.out.println("class B method called");
}
}
