package com.overriding_static_nonstatic;
//we can not override static and non static methods
//static method are class level methods
//non static methods are object level method
public class A {
public static void m1(){
	System.out.println("class A method called");
}
public void m2(){
	System.out.println("class AA method called");
}
}
