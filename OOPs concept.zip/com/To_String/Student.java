package com.To_String;

public class Student {
int rollNo;
//camelcasing
String name;
String surName;
//user defined method
public String m1(){
	return "Student [ rollNo=" + rollNo + ", name=" + name + ", surName=" + surName + " ]";
}
public String toString() {
	return "Student [rollNo=" + rollNo + ", name=" + name + ", surName="
			+ surName + "]";
}
public static void main(String[]args){
	Student s1=new Student();
	s1.rollNo = 1;
	s1.name ="Pooja";
	s1.surName="anarthe";
	System.out.println(s1.m1());
	System.out.println(s1.toString());
}

}
