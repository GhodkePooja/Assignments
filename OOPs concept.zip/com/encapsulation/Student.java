package com.encapsulation;

public class Student {
private int id;
private String name;
public void setId(int id)
{
	this.id=id;
	System.out.println("user is changing the ID");
}
public int getId(){
System.out.println("user is fetching this value");
return this.id;
}
public void setString(String name){
	this.name=name;

}
public String getname(){
	return this.name;
}
}

