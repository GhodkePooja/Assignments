package com.encapsulation;

public class Student1 {
private int id;
private String name;
public void setId(int id){
this.id=id;
System.out.println("user is changing id");
}
public int getId(){
	System.out.println("user is fetching data");
	return this.id;
}
public void setString(String name){
	this.name=name;
	}
public String getname(){
	return this.name;
	
}//encapsulation
public static void main(String[]args){
	Student1 s1=new Student1();
	s1.setId(10);
	System.out.println(s1.getId());
	s1.setString("diyara anarthe");
	System.out.println(s1.getname());
}
}



