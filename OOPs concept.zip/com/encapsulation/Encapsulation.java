package com.encapsulation;

public class Encapsulation extends Student{
public static void main (String[]args){
	Student s1=new Student();
	s1.setId(10);
	System.out.println(s1.getId());
	s1.setString("pooja anarthe");
	System.out.println(s1.getname());
}
}
