package com.encapsulation;

public class Student2 {
private int id;
private String name;
public void  setId(int id){
	this.id=id;
	System.out.println("user is changing id");
	
}
public int getId(){
	System.out.println("user is fetching information");
	return this.id;
	
}
public void setString(String name){
	this.name=name;
	
}
public String getname(){
	return this.name;
	
}
public static void main(String[]args){
	Student2 s2=new Student2();
	s2.setId(5);
	System.out.println(s2.getId());
	s2.setString("satish anarthe");
	System.out.println(s2.getname());
}
}
