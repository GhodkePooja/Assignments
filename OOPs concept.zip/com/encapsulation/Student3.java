package com.encapsulation;

public class Student3 {
private int id;
private String name;
public void setId(int id){
	this.id=id;
	System.out.println("user is changing id");
}
public int getId(){
	System.out.println("user is fetching data");
	return this.id;
}
public void setString(String name){
	this.name=name;
	System.out.println("user is changing name");
}
public String getName(){
	System.out.println("user is fetching information");
	return this.name;
}
public static void main(String[]args){
	Student3 s1=new Student3();
	s1.setId(1);
	System.out.println(s1.getId());
	s1.setString("pooja satish anarthe");
	System.out.println(s1.getName());
}
}
