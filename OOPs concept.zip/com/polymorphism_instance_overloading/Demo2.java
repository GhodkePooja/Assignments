package com.polymorphism_instance_overloading;
//type 2
public class Demo2 {
public void m1(int i){
	System.out.println("int argument called");
}
public void m1(int i,long j){
	System.out.println("int and long argument called");
}
public void m1(int i,long j,double d){
	System.out.println("int,long,double argument called");
}
public void m1(int i,long j,double d,float f){
	System.out.println("int,long,double,float argument called");
}
public static void main(String[]args){
	Demo2 d1=new Demo2();
	d1.m1(5);
	d1.m1(5,10);
	d1.m1(5,10,10.0);
	d1.m1(5,10,10.0,25.0f);
	
	
	
}
}
