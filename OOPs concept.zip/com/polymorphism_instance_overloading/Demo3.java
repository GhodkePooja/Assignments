package com.polymorphism_instance_overloading;

//type 3:by changing sequence of parameter
public class Demo3 {
	public void m1(int i, double j) {
		System.out.println("int and double argument passed");
	}

	public void m1(double j, int i) {
		System.out.println("double and int argument passed");
	}

	
	public static void main(String[] args) {
		Demo3 d1 = new Demo3();
		d1.m1(10, 50.0);
		d1.m1(50.0, 10);
	}

}
