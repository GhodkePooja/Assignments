package com.polymorphism_instance_overloading;
//type 3:by changing sequence of parameter
public class Demo4 {
public void m1(int i,long l){
	System.out.println("int and long argument passed");
}
public void m1(long l,int i){
	System.out.println("long and int argument passed");
}
public static void main (String[]args){
	Demo4 d1=new Demo4();
	d1.m1(10, 50l);
	d1.m1(50l, 10);
}
}
