package com.polymorphism_instance_overloading;
//different parameter and method name 
//it is not a method overloading..not allowed
public class Demo5_NotOverloaded {
public void m1(int i,String s){
	System.out.println("int and string argument passed");
}
public void m2(String s,int i){
	System.out.println("string and int argument passed");
}
public static void main(String[]args){
	Demo5_NotOverloaded d1=new Demo5_NotOverloaded();
	d1.m1(10, "pooja");
	d1.m2("pooja", 10);
}
}
