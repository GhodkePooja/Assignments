package com.polymorphism_instance_overloading;
// datatype parameter are different type 1
public class Demo {
public void m1(int i){
	System.out.println("int method called");
}
public void m1(long l){
	System.out.println("long method called");
}
public void m1(double d){
	System.out.println("double method called");
}
public void m1(short s){
	System.out.println("short method called");
}
public void m1(char c){
	System.out.println("char method called");
}
public void m1(float f){
	System.out.println("float method called");
}
public static void main(String[]args){
	Demo d1=new Demo();
	d1.m1(10);
	d1.m1(10l);
	d1.m1(10.0d);
	d1.m1((short)11);//we have to explicit here
	d1.m1('A');
	d1.m1(10.0f);
	

}
}
