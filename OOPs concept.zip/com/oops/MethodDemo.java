package com.oops;

public class MethodDemo {
	//syntax: <access modifier><return type><name of method()>{}
	
public void addition(){
	int a=10;
	int b=20;
	int sum=a+b;
	System.out.println("addition of a and b:"+sum);//i can't access this method directly hence we did not get any o/p.
}
public void substraction(){
	int a=10;
	int b=5;
	int sub=a-b;
	System.out.println("substraction of a and b:"+sub);
}
public void multiplication(){
	int a=10;
	int b=5;
	int mul=a*b;
	System.out.println("multiplication of and b:"+mul);
}
public void division(){
	int a=20;
	int b=5;
	int div=a/b;
	System.out.println("division of a and b:"+div);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
MethodDemo m=new MethodDemo();
m.addition();
m.substraction();
m.multiplication();
m.division();

	}

}
