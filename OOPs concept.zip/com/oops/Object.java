package com.oops;

public class Object {
	int i;
	public static void main(String[]args){
	Object a=new Object();
	System.out.println(a.i);

}
	}
