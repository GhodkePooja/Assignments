package com.oops;

public class Class {
	int rollNo;
	String name;
	String surName;
	public void m1(){
		
	}
public static void main(String[]args){
	Class c1=new Class();
	Class c2=new Class();
	Class c3=new Class();
}
}
