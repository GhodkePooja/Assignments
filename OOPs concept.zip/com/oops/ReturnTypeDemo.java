package com.oops;

public class ReturnTypeDemo {
	public void m2(){
		System.out.println("hello");
	}
public boolean m1(){
	return true;
}
public static void main(String[]args){
	ReturnTypeDemo r1=new ReturnTypeDemo();
System.out.println(r1.m1());
r1.m2();
}
}
