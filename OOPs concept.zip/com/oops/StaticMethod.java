package com.oops;

public class StaticMethod {
	static int i;
public static void m1(){
	System.out.println("hello");
}
public static void main(String[]args){
	System.out.println(i);
	m1();
	//we can also write
	System.out.println(StaticMethod.i);
	StaticMethod.m1();
	//by creating object
	StaticMethod m=new StaticMethod();
	System.out.println(m.i);
	m.m1();
}
}
