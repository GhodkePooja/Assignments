package com.data_abstraction;
//data abstraction is the property in which only essential details are shown to user
//we achieve abstraction in java using abstact class and interfaces
//by using abstract modifier we can declare method in abstaction method
//and implementation of method is required to give in another class
public class A {
public int addition(int num1 ,int num2){
	return num1+num2;
}
}
