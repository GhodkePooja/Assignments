package com.data_abstraction;

abstract class Demo {
int a;
abstract int addition(int num1,int num2);
//abstraction method
public void m1(){
	int num1=10;
	int num2=20;
	System.out.println(num1 + num2);
}
public void m2(){
	//non abstraction method
	System.out.println("hello");
}}