package com.runtime_polymorphism_checkedexception;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class BB extends AA {
//FileNotFoundException-checked exception
	public void m1()throws FileNotFoundException{
		//logic to get data from ab.txt.file
	}
	public void m2()throws FileNotFoundException{
		//logic
	}
	//caller
	//public void m3()throws FileNotFoundException{
		//logic
	//}
public void m4()throws FileNotFoundException{
	FileReader f=new FileReader("/Users/Desktop");
}
}
