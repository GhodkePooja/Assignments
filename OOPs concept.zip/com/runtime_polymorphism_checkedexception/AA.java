package com.runtime_polymorphism_checkedexception;
import java.io.FileNotFoundException;
public class AA {
public void m1()throws FileNotFoundException{
	System.out.println("class AA method");
}
public void m2()throws Exception{
	
}
public void m3()throws ClassNotFoundException{
	
}
}
