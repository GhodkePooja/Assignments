package com.polymorphism_static_overloading;

public class Demo {
	public static void m1() {
		System.out.println("no argument");
	}

	public static void m1(int i) {
		System.out.println("int argument passed");
	}

	public static void m1(float f) {
		System.out.println("float method argument passed");
	}

	public static void main(String[] args) {
		m1();
		m1(10);
		m1(10.00f);
	}
}
