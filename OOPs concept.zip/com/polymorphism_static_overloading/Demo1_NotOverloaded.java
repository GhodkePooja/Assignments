package com.polymorphism_static_overloading;
//these two methods are diiferent one from instance and another is from
//static method hence these two method are not overloaded
public class Demo1_NotOverloaded {
public static void m1(){
	System.out.println("no args  static method");
}
public void m1(int i){
	System.out.println("int args instance method");
}
public static void main(String[]args){
	m1();
	Demo1_NotOverloaded d1=new Demo1_NotOverloaded();
	d1.m1(10);

}
}