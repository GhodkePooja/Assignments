package com.polymorphism_static_overloading;
//return type does not matter in method overloading
public class ReturnType {
public void m1(){
	System.out.println("return void type means null value");
}
public int m1(int i){
	
	System.out.println("int argument return type");
	return 0;
}
public static void main(String[]args){
	ReturnType r1=new ReturnType();
	r1.m1();
	r1.m1(10);
	
}
}
