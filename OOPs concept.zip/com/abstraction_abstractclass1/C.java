package com.abstraction_abstractclass1;

public  class C extends B {

	@Override
	void m2() {
	
		System.out.println("class c m2 method called");
	}
public static void main(String[]args){
	C c1=new C();
	c1.m1();
	c1.m2();
	B b1=new C();
	b1.m1();
	b1.m2();
	A a1=new C();
	a1.m1();
	a1.m2();
}
}
