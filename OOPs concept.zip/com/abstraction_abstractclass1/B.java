package com.abstraction_abstractclass1;

public abstract class B extends A {

	@Override
	void m1() {
		System.out.println("class A m1 method called");
		
	}

	@Override
	abstract void m2() ;
	
	}


