package com.abstraction_abstractclass1;

abstract class A {
static int k;
int a;
private int i=10;
abstract void m1();
abstract void m2();
}
