package com.hierarchicalinheritance;

public class Child2 extends Parent {
public void m2(){
	System.out.println("child 2 method called");
}
public static void main(String[]args){
	Child2 c1=new Child2();
	c1.m1();
	c1.m2();
}
}
