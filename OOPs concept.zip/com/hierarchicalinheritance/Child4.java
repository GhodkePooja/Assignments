package com.hierarchicalinheritance;

public class Child4 extends Parent {
public void m2(){
	System.out.println("child 4 metod called");
	
}
public static void main(String[]args){
	Child4 c1=new Child4();
	c1.m1();
	c1.m2();
}
}
