package com.methodoverriding;

public class A {
public void m1(){
	System.out.println("class A  parent method called");
}
}
