package com.methodoverriding;

public class B extends A {
	public void m1(int a) {
		System.out.println("int argument passed");
	}

	public void m1(long l) {
		System.out.println("long argument passed");
	}

	public static void main(String[] args) {
		// parent object created by using parent reference
		A a1 = new A();
		a1.m1();

		// child method created by using child reference
		B b1 = new B();
		b1.m1(10);

		// child object by using reference of parent
		A a2 = new B();
		a2.m1();
	}
}
