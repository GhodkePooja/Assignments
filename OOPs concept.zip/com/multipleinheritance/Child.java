package com.multipleinheritance;

//public class Child extends Parent1 extends Parent2{
//public void m2(){
//	System.out.println("child method");
//}
//}
