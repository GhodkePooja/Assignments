package com.runtime_polymorphism_superclass;

public class B extends A {
public void m1(){
	super.m1();
}
public static void main(String[]args){
	A a1=new B();
	a1.m1();
}
}
