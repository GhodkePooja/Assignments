package com.multilevelinheritance;

public class B extends A {
public void method2(){
	System.out.println("class B method");
}

}
