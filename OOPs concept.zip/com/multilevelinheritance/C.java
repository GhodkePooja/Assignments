package com.multilevelinheritance;

public class C extends B {
public void method3(){
	System.out.println("class C method");
}
public static void main(String[]args){
	//object of A class
	A a1=new A();
	a1.method1();
	//object of B class
	B b1=new B();
	b1.method1();
	b1.method2();
	//object of C class
	C c1=new C();
	c1.method1();
	c1.method2();
	c1.method3();
	//object of B using reference A
	A a2=new B();
	a2.method1();
	//object of C using reference A
	A a3=new C();
	a3.method1();
	//object of C using reference B
	B b2=new C();
	b2.method1();
	b2.method2();
	
	
	
}
}

