package com.multilevelinheritance;

public class A {
public void method1(){
	System.out.println("class A method");
}
}
