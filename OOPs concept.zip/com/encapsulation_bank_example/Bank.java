package com.encapsulation_bank_example;
 
 public class Bank {
float getRateOfInterest(){
	return 0;
}}
  class SbiBank extends Bank{
float getRateOfInterest(){
	return 10.8f;
}}
 class AxisBank extends Bank{
float getRateofInterest(){
	return 9.8f;
	
}}
  class IciciBank extends Bank{
float getRateofInterest(){
	return 8.97f;
}}
  class UnionBank extends Bank {
float UROI;
float getRateOfInterest(){
	Bank b=new SbiBank();
	float RSBI=b.getRateOfInterest();
	System.out.println(RSBI);
	UROI=(RSBI-((RSBI/100)*20));
	return UROI;
}}
  class AllBank
  {
	public static void main(String[]args){
	Bank b1=new SbiBank();
	System.out.println("rate of interest SbiBank:"+ b1.getRateOfInterest());
	Bank b2=new AxisBank();
	System.out.println("rate of interest AxisBank:"+ b2.getRateOfInterest());
	Bank b3=new IciciBank();
	System.out.println("rate of interest IciciBank:"+ b3.getRateOfInterest());
	Bank b4=new UnionBank();
	System.out.println("rate of interest Union Bank:"+ b4.getRateOfInterest());
	}
		
	}

	

