package com.private_samepackage_subclass;

public class A {
private void m1(){
	System.out.println("class A method called");
}

}
