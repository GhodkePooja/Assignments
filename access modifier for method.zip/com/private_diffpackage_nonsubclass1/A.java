package com.private_diffpackage_nonsubclass1;

public class A {
private void m1(){
	System.out.println("class A method called");
}
}
