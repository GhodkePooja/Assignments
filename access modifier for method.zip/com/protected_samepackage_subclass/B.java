package com.protected_samepackage_subclass;

public class B extends A {
public static void main(String[]args){
	B b1=new B();
	b1.m1();
}
}
