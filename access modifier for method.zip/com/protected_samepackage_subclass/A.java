package com.protected_samepackage_subclass;

public class A {
protected void m1(){
	System.out.println("class A method called");
}
public static void main(String[]args){
	A a1=new A();
	a1.m1();
}
}
