package com.protected_diffpackage_nonsubclass1;

public class A1 {
protected void m1(){
	System.out.println("class A1 method called");
}
}
