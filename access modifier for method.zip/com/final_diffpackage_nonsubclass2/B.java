package com.final_diffpackage_nonsubclass2;

import com.final_diffpackage_nonsubclass1.A;
public class B {
public static void main(String[]args){
	A a1=new A();
	//a1.m1();not allowed
}
}
