package com.overriding_static_nonstatic;

//public class B extends A {
//public void m1(){
//	System.out.println("class B method called");
//}
//public static void m2(){
//	System.out.println("class BB method called");
//}
//public static void main(String[]args){
//	A a1=new B();
//	a1.m2();
//}
//}
