package com.singleinheritance;

public class UnicornBike {
public void IncreasedSpeed(){
	System.out.println("speed is increased");
}
public void DecreasedSpeed(){
	System.out.println("speed is decreased");
}
public static void main(String[]args){
 UnicornBike b1=new UnicornBike();
 b1.IncreasedSpeed();
 b1.DecreasedSpeed();
}
}
