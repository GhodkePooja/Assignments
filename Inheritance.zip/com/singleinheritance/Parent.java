package com.singleinheritance;

public class Parent {
public void method1(){
	System.out.println("parent method called");
}
}
