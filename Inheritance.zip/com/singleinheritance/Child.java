package com.singleinheritance;

public class Child extends Parent {
public void m2(){
	System.out.println("child method called");
}
public static void main(String[]args){
	//we can only call here parent object using parent reference
	Parent p1=new Parent();
	p1.method1();
	
	//we can call here parent method as well as child method
	Child c1=new Child();
	c1.method1();
	c1.m2();
	//by using parent reference we create here child object but we can't access
	//properties of child
	Parent p2=new Child();
	p2.method1();

	
	
}
}
