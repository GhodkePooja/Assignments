package com.singleinheritance;

public class ShineBike extends UnicornBike {


public static void main(String[]args){
	//object created child reference and child object
	ShineBike s1=new ShineBike();
	s1.IncreasedSpeed();
	s1.DecreasedSpeed();
	
	UnicornBike s2=new UnicornBike();
	s2.IncreasedSpeed();
	s2.DecreasedSpeed();
	
	UnicornBike s3=new UnicornBike();
	s3.IncreasedSpeed();
	s3.DecreasedSpeed();
	
	
	
}}