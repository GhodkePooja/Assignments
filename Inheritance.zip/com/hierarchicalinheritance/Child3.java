package com.hierarchicalinheritance;

public class Child3 extends Parent {
public void m2(){
	System.out.println("child 3 method called");
}
public static void main(String[]args){
	Child3 c1=new Child3();
	c1.m1();
	c1.m2();
}
}
