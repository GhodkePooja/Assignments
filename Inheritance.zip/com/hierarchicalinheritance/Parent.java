package com.hierarchicalinheritance;

public class Parent {
public void m1(){
	System.out.println("parent method calling");
}
}
