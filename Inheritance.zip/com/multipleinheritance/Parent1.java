package com.multipleinheritance;

public class Parent1 {
public void m1(){
	System.out.println("parent 1 method call");
}
}
