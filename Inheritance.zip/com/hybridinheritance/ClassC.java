package com.hybridinheritance;

public class ClassC extends ClassB{
public void m3(){
	System.out.println("class C method called");
}
}
