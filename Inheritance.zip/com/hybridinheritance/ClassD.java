package com.hybridinheritance;

public class ClassD extends ClassA {
public void m4(){
	System.out.println("class D method called");
}
}
