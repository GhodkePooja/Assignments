package operator;

public class defaultvaluedouble {
	double d;

	public static void main(String[] args) {

		defaultvaluedouble s = new defaultvaluedouble();
		System.out.println(s.d);
	}
}
