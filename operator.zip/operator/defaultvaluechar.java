package operator;

public class defaultvaluechar {
char c;
public static void main(String[] args){
	defaultvaluechar d= new defaultvaluechar();
	System.out.println(d.c);
	
	
}
}
