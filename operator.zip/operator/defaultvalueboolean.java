package operator;

public class defaultvalueboolean {
boolean b;
public static void main(String[]args){
	
	defaultvalueboolean d= new defaultvalueboolean();
	System.out.println(d.b);
	
}
}
