package operator;

public class defaultvalueshort {
	short s;

	public static void main(String[] args) {

		defaultvalueshort t = new defaultvalueshort();
		System.out.println(t.s);
	}
}
