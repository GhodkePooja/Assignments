package operator;

public class demodouble {
public static void main(String[]args){
	double d=13.8675423536;
	System.out.println(d);
	
	
}
}
