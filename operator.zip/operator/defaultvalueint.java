package operator;

public class defaultvalueint {
	int i;

	public static void main(String[] args) {

		defaultvalueint a = new defaultvalueint();
		System.out.println(a.i);
	}
}
