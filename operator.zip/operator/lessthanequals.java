package operator;

public class lessthanequals {
public static void main(String[] args){
	int a=9;
	int b=9;
	boolean k=(a<=b);
	System.out.println(k);
	
	
	
}
}
