package operator;

public class lessthan {
public static void main(String [] args){
	int a=5;
	int b=9;
	boolean k=(a<b);
	System.out.println("value of boolean k:"+k);
	
	
	
}
}
