package operator;

public class defaultvaluefloat {
	float f;

	public static void main(String[] args) {
		defaultvaluefloat r = new defaultvaluefloat();
		System.out.println(r.f);

	}
}
