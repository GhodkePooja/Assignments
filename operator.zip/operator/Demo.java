package operator;

public class Demo {

}
