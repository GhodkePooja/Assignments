package operator;

public class demofloat {
public static void main(String[] args){
	float f=12.569564256f;
	System.out.println(f);
	
}
}
