package operator;

public class greaterthan {
public static void main(String[] args){
	int a=11;
	int b=2;
	boolean c=(a>b);
	System.out.println(c);
	
	
}
}
