package operator;

public class defaultvaluelong {
	long l;

	public static void main(String[] args) {

		defaultvaluelong y = new defaultvaluelong();
		System.out.println(y.l);

	}
}
