package operator;

public class greaterthanequals {
	public static void main(String[] args) {
		int a = 100;
		int b = 54;
		boolean c = (a >= b);
		System.out.println(c);
	}
}
