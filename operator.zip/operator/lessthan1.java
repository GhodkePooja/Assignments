package operator;

public class lessthan1 {
	public static void main(String[] args) {
		int a = 56;
		int b = 45;
		boolean c = (a < b);
		System.out.println(c);

	}
}
