package operator;

public class graterthan1 {
	public static void main(String[] args) {
		int a = 10;
		int b = 25;
		boolean c = (a > b);
		System.out.println(c);

	}
}
