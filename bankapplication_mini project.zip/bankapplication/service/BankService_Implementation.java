package com.bankapplication.service;
import java.util.Scanner;
import java.util.Random;

import com.bankapplication.model.Account;

public class BankService_Implementation implements BankService {
	Account ac=new Account();
	Scanner sc=new Scanner(System.in);

	public void createBankAccount() {
		System.out.println("enter your name");
		String name=sc.next();
		ac.setUser_name(name);
		System.out.println("enter your address");
		String address=sc.next();
		ac.setUser_address(address);
		System.out.println("enter your pan number");
		String Pan_no=sc.next();
		ac.setPan_no(Pan_no);
		System.out.println("enter amount to deposit");
		int deposit=sc.nextInt();
		ac.setBalance(deposit);
		if( deposit>=1000){
		
		//generating random number
		Random random=new Random();
		
		long accno=random.nextLong() ;
		
		ac.setAcc_no(accno);
		Math.abs(accno);
		System.out.println("your account is created successfully and your account number is:" +ac.getAcc_no());
		}
		else{
			System.out.println("minimum ammount 1000 you have to deposit");
		}
		}
	
		
	
	public void viewAccountDetails() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		long userAccountNumber=sc.nextLong();
		if(ac.getAcc_no()==userAccountNumber){
			System.out.println("fetching acount details");
			System.out.println(ac.getAcc_no());
			System.out.println(ac.getUser_name());
			System.out.println(ac.getUser_address());
			System.out.println(ac.getPan_no());
			System.out.println(ac.getBalance());
			ac.toString();
		}
		else{
			System.out.println("create your new account first");
	
	}}

	public void withdrawMoney() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		long accno=sc.nextLong();
		if(ac.getAcc_no()==accno){
		
		System.out.println("enter amount to withdrawn");}
		
		int accountBalance=ac.getBalance();
		int withdraw=sc.nextInt();
		if(ac.getBalance()>=500){
			int i=100;
			if(ac.getBalance()%100==0){
				
				
			if(ac.getBalance()<=accountBalance){
				accountBalance=accountBalance-withdraw;
				System.out.println("your amount withdraw successfully");
				System.out.println("please collect your cash");
				System.out.println("your available balance is:"+accountBalance);
				ac.toString();
			
			}}}
				else{	  System.out.println("insufficiant funds");
					System.out.println("you can not withdraw below 500 rupees");
			
				System.out.println("you have to withdraw amount multiple of 100 only");}
			
		{
	 	           
				System.out.println("first create account number");
				
			}
	}
			
		

	public void depositMoney() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		long accno=sc.nextLong();
		if(ac.getAcc_no()==accno){
			
		System.out.println("enter amount to deposit");}
		int balance1=ac.getBalance();
		int deposit=sc.nextInt();
		
		if(ac.getBalance()<=balance1){
		balance1=balance1+deposit;
			System.out.println("your amount is deposited successfully");
			System.out.println("your current account balance is:"+balance1);
			
			}else{
				System.out.println("something went wrong");
				
			}
	}

	public void updateAccountDetails() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		long accno=sc.nextLong();
		if(ac.getAcc_no()==accno){
			boolean flag=true;
			
			while(flag){
			System.out.println("press 1 for change your user name");
			System.out.println("press 2 for change your address");
			System.out.println("press 3 for change your pan number");
			System.out.println("press 4 for exit ");
			int ch=sc.nextInt();
			switch(ch){
			
			case 1: System.out.println(" enter the name which you want to update");
	        String user_name=sc.next();
	        ac.setUser_name(user_name);
			System.out.println("name updated successfully and updated details are:"+ac.getUser_name());
			break;
			
			case 2: System.out.println("enter the address which you want to update");
			String user_address=sc.next();
			ac.setUser_address(user_address);
			System.out.println(" address updated successfully and updated details are:"+ac.getUser_address());
			break;
			
			case 3:System.out.println("enter the pan number which you want to update ");
			String pan_number=sc.next();
			ac.setPan_no(pan_number);
			System.out.println("pan number updated successfully and updated details are:"+ac.getPan_no());
			break;
	
			case 4: flag=false;
			break;
				
			default:System.out.println("invalid choice!!!");

			}
		}}
			
		else{
			System.out.println("create account first");
		}
	}


	public void viewAccountBalance() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		long accno=sc.nextLong();
		
		
		if(ac.getAcc_no()==accno){
			
			System.out.println("your are login successfully");

		
				System.out.println("your available balance is:"+ac.getBalance());
		}
			
	else{
			System.out.println("something went wrong");
		}
	}

}
