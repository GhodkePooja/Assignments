package com.bankapplication.controller;
import com.bankapplication.service.*;
import java.util.Scanner;
import java.util.Random;

import com.bankapplication.service.BankService;
import com.bankapplication.service.BankService_Implementation;

public class BankApplication {
public static void main(String[]args){
	BankService b1= new BankService_Implementation();
	boolean flag=true;
	while(flag){
		System.out.println("press 1 for account creation");
		System.out.println("press 2 for view account details");
		System.out.println("press 3 for withdraw money");
		System.out.println("press 4 for deposit money");
		System.out.println("press 5 for update account details");
		System.out.println("press 6 for check your available balance");
		System.out.println("press 7 for Exit");
	
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		switch(ch){
		case 1:b1.createBankAccount();
		break;
		case 2:b1.viewAccountDetails();
		break;
		case 3:b1.withdrawMoney();
		break;
		case 4:b1.depositMoney();
		break;
		case 5:b1.updateAccountDetails();
		break;
		case 6:b1.viewAccountBalance();
		break;
		case 7:flag=false;
		break;
        default:System.out.println("invalid choice");
		}
	}}}