package com.bankapplication.model;

public class Account {
private long acc_no;
private String user_name;
private String user_address;
private String pan_no;
private int balance;


public long getAcc_no() {
	return acc_no;
}
public void setAcc_no(long accno) {
	this.acc_no = accno;
}
public String getUser_name(){ 
	return user_name;
}
public void setUser_name(String user_name) {
	this.user_name = user_name;
}
public String getUser_address() {
	return user_address;
}
public void setUser_address(String user_address) {
	this.user_address = user_address;
}
public String getPan_no() {
	return pan_no;
}
public void setPan_no(String pan_no) {
	this.pan_no = pan_no;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public String toString() {
	return "Account [acc_no=" + acc_no + ", user_name=" + user_name
			+ ", user_address=" + user_address + ", pan_no=" + pan_no
			+ ", balance=" + balance + "]";
}

}
